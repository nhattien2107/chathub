﻿using Microsoft.AspNetCore.SignalR;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;

namespace DemoChat.Hubs
{
    public class ChatHub : Hub
    {
        public async Task SendMessage(string username, string message)
        {
            // Call the addNewMessageToPage method to update clients.
            await Clients.All.SendAsync("ReceivedMessage", username, message);
        }
    }
}
